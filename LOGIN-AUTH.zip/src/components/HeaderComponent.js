import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';

class HeaderComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {};
    }

    render() {
        // Check the current route
        const { pathname } = this.props.location;
        const shouldRenderLogout = !['/register', '/login', '/', '/AdminLogin', '/forgot-password'].includes(pathname);

        const headerStyle = {
            display: 'flex',
            justifyContent: 'space-between'
        };

        return (
            <div>
                <header>
                    <nav className="navbar navbar-expand-md navbar-dark bg-dark" style={headerStyle}>
                        <div>
                            <Link to="/" className="navbar-brand">CALMLY</Link>
                        </div>
                        {shouldRenderLogout && (
                            <div>
                                <Link to="/" className="btn btn-danger">Logout</Link>
                            </div>
                        )}
                    </nav>
                </header>
            </div>
        );
    }
}

export default withRouter(HeaderComponent);