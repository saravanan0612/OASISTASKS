import React from 'react';
import Navbar from '../Navbar/Navbar';
import './About.css';

const About = () => {
  return (
    <div className="about-container">
      <Navbar />
      <header className="about-header">
        <h1>About the Meditation App</h1>
        <p>Discover Inner Peace and Relaxation</p>
      </header>

      <div className="about-content">
        <p>
          Welcome to the Meditation App, your gateway to a world of mindfulness, relaxation, and personal growth. Our mission is to provide you with the tools and resources to find inner peace and lead a healthier, happier life.
        </p>

        <p>
          Meditation is a practice that involves focusing your mind on a particular object, thought, or activity to train attention and awareness. It is often used to reduce stress, promote relaxation, and enhance personal and spiritual growth. Meditation can have a positive impact on your physical and mental well-being, helping you find inner peace and clarity.
        </p>

        <p>
          Our platform offers a range of guided meditation sessions led by experts, mindfulness exercises to reduce stress and enhance well-being, and relaxation techniques for a calm and focused mind. Whether you're a beginner or an experienced meditator, our app is designed to meet your needs.
        </p>

        <p>
          We are committed to making meditation courses affordable and accessible to all. Our prices vary based on the type of course and duration. If you have any questions or need detailed pricing information, please don't hesitate to contact us.
        </p>
      </div>
    </div>
  );
};

export default About;
