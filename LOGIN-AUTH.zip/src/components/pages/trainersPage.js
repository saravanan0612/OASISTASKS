import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
const TrainersPage = () => {
  const [trainers, setTrainers] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8080/api/trainer/get', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json', // You can include other headers if needed
        },
      });

      if (response.ok) {
        const data = await response.json();
        setTrainers(data);
      } else {
        console.error('Failed to fetch trainer data. Please try again.');
      }
    } catch (error) {
      console.error('An error occurred:', error);
    }
  };

  return (
    <div className="trainers-page">
      <h1 className="trainer-list-title">Trainer List</h1>
      <Link to="/UsersPage">
        <button className="courses-button">Courses</button>
      </Link>
      <Link to="/home">
        <button className="courses-button">back</button>
      </Link>
      <table className="trainer-table">
        <thead>
          <tr>
            <th className="trainer-name">Trainer Name</th>
            <th className="email">Email</th>
            <th className="category">Category</th>
          </tr>
        </thead>
        <tbody>
          {trainers.map((trainer) => (
            <tr key={trainer.id}>
              <td className="trainer-name">{trainer.trainername}</td>
              <td className="email">{trainer.email}</td>
              <td className="category">{trainer.category}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TrainersPage;