import React, { useState } from 'react';
import './MeditationSession.css';

const MeditationSession = ({ session, onAddToPlaylist, onRemoveFromPlaylist }) => {
  const isAddedToPlaylist = session.addedToPlaylist;

  return (
    <div className="meditation-session">
      <h2>{session.title}</h2>
      <p>{session.description}</p>
      {isAddedToPlaylist ? (
        <button onClick={() => onRemoveFromPlaylist(session)}>Remove from Playlist</button>
      ) : (
        <button onClick={() => onAddToPlaylist(session)}>Add to Playlist</button>
      )}
    </div>
  );
};

const Playlist = ({ playlist, onRemoveFromPlaylist }) => {
  return (
    <div className="playlist">
      <h2>Your Playlist</h2>
      {playlist.map((session) => (
        <div key={session.id} className="playlist-session">
          <h3>{session.title}</h3>
          <p>{session.description}</p>
          <button onClick={() => onRemoveFromPlaylist(session)}>Remove from Playlist</button>
        </div>
      ))}
    </div>
  );
};

const App = () => {
  const [meditationSessions, setMeditationSessions] = useState([
    { id: 1, title: 'Session 1', description: 'Description 1', addedToPlaylist: false },
    { id: 2, title: 'Session 2', description: 'Description 2', addedToPlaylist: false },
    // Add more sessions as needed
  ]);

  const [playlist, setPlaylist] = useState([]);

  const handleAddToPlaylist = (session) => {
    const updatedSessions = meditationSessions.map((s) =>
      s.id === session.id ? { ...s, addedToPlaylist: true } : s
    );
    setMeditationSessions(updatedSessions);
    setPlaylist([...playlist, session]);
  };

  const handleRemoveFromPlaylist = (session) => {
    const updatedSessions = meditationSessions.map((s) =>
      s.id === session.id ? { ...s, addedToPlaylist: false } : s
    );
    setMeditationSessions(updatedSessions);
    const updatedPlaylist = playlist.filter((s) => s.id !== session.id);
    setPlaylist(updatedPlaylist);
  };

  return (
    <div className="container">
      <h1>Meditation Playlist Creator</h1>
      <div className="content">
        <div className="meditation-sessions">
          <h2>Meditation Sessions</h2>
          {meditationSessions.map((session) => (
            <MeditationSession
              key={session.id}
              session={session}
              onAddToPlaylist={handleAddToPlaylist}
              onRemoveFromPlaylist={handleRemoveFromPlaylist}
            />
          ))}
        </div>
        <Playlist playlist={playlist} onRemoveFromPlaylist={handleRemoveFromPlaylist} />
      </div>
    </div>
  );
};

export default App;
