// AudioPlayer.js
import React from 'react';

const AudioPlayer = ({ track }) => {
  if (!track) {
    return <div>Choose a track to play.</div>;
  }

  return (
    <div>
      <h2>Now Playing: {track.title}</h2>
      <audio controls>
        <source src={track.src} type="audio/mpeg" />
      </audio>
    </div>
  );
};

export default AudioPlayer;
