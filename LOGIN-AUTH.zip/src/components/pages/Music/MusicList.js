// MusicList.js
import React from 'react';

const MusicList = ({ musicData, onTrackSelect, onAddToPlaylist }) => {
  return (
    <div>
      <h2>Music List</h2>
      <ul>
        {musicData.map((track, index) => (
          <li key={index}>
            {track.title}
            <button onClick={() => onTrackSelect(track)}>Play</button>
            <button onClick={() => onAddToPlaylist(track)}>Add to Playlist</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MusicList;
