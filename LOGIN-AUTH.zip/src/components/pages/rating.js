import React, { useState } from 'react';
import toast, { Toaster } from 'react-hot-toast';
import { FaStar } from 'react-icons/fa';
import ThankYouModal from '../pages/ThankyouModel';
import './rating.css';
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min';

const StarRating = () => {
  const navigate = useHistory();
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [showModal, setShowModal] = useState(false);

  const handleMouseOver = (index) => {
    setHover(index);
  };

  const handleMouseLeave = () => {
    setHover(0);
  };

  const handleClick = (index) => {
    setRating(index);
  };

  const handleFeedbackChange = (event) => {
    setFeedback(event.target.value);
  };

  const handleSubmit = () => {
    // You can handle the submission of rating and feedback here
    console.log(`Rating: ${rating}, Feedback: ${feedback}`);
    toast.success('Thank you for your Feedback');
    setTimeout(() => {
      navigate.push('/home');
    }, 2000);

    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  return (
    <div className="container">
      <Toaster position="top-center" reverseOrder={false} />
      <div className="star-container">
        {[...Array(5)].map((star, index) => {
          const ratingValue = index + 1;

          return (
            <label key={index} className="star-label">
              <input
                type="radio"
                name="rating"
                value={ratingValue}
                onClick={() => handleClick(ratingValue)}
                className="star-input"
              />
              <FaStar
                className="star-icon"
                size={25}
                onMouseOver={() => handleMouseOver(ratingValue)}
                onMouseLeave={handleMouseLeave}
                style={{ color: ratingValue <= (hover || rating) ? 'gold' : 'gray' }}
              />
            </label>
          );
        })}
      </div>
      <p className="feedback-label">Your rating is: {rating}</p>
      <textarea
        rows="4"
        cols="50"
        placeholder="Provide your feedback here..."
        value={feedback}
        onChange={handleFeedbackChange}
        className="feedback-textarea"
      />
      <button className="submit-button" onClick={handleSubmit}>
        Submit
      </button>

      {showModal && <ThankYouModal onClose={closeModal} />}
    </div>
  );
};

export default StarRating;
