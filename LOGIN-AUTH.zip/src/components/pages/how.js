// ImageGrid.js

import React, { Component } from 'react';

class ImageGrid extends Component {
    constructor(props) {
        super(props);

        this.state = {
            imageUrls: [
                "https://i.insider.com/5ee7e547191824461b6405b8?width=700",
                "https://img.freepik.com/free-photo/young-woman-doing-half-lotus-toe-balance-exercise_1163-5069.jpg?w=996&t=st=1700241555~exp=1700242155~hmac=b86481dea47d47e2b34eebdf253d2626a970fc85f498d85629bb58412d891214",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRjDnTbjtgI9BjFxl9fGHu9dS8bG7isC2rHg_b__l_vXRJzTk17A1ktBAV8szzTBo0SvAA&usqp=CAU",
                "https://www.skepticspath.org/wp-content/uploads/2021/10/4-burmese.jpg",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2T3MNiVKdNMC7EigYYwQgsGyslThgi0rER3uD_ZHoQf2a5Vt3XUhucmFnmTGKIN7w0ME&usqp=CAU",
                "https://thumbs.dreamstime.com/z/yoga-posture-21621679.jpg?w=992",
                "https://thumbs.dreamstime.com/z/yoga-downward-facing-dog-pose-cartoon-vector-illustration-posture-eps-file-format-70879550.jpg?w=576",
                "https://thumbs.dreamstime.com/b/yoga-half-lord-fishes-pose-cartoon-vector-illustration-posture-eps-file-format-82664020.jpg",
                "https://thumbs.dreamstime.com/b/yoga-eagle-pose-cartoon-vector-illustration-posture-eps-file-format-72470717.jpg",
                "https://thumbs.dreamstime.com/b/yoga-cobra-pose-cartoon-vector-illustration-posture-eps-file-format-70879047.jpg",
                "https://thumbs.dreamstime.com/b/yoga-chair-pose-cartoon-vector-illustration-posture-eps-file-format-77060578.jpg?w=360",
                "https://thumbs.dreamstime.com/b/yoga-child-s-pose-cartoon-vector-illustration-posture-eps-file-format-76354059.jpg?w=360",
                "https://thumbs.dreamstime.com/b/pretty-girl-yoga-time-20589056.jpg?w=360",
                "https://thumbs.dreamstime.com/b/yoga-woman-8747590.jpg?w=360",
                "https://thumbs.dreamstime.com/b/doing-yoga-female-asian-teenager-exercising-against-white-background-32551752.jpg?w=360",
                "https://thumbs.dreamstime.com/b/woman-doing-pilates-isolated-white-background-32129347.jpg?w=360",
                "https://thumbs.dreamstime.com/b/stretching-legs-27007485.jpg?w=360",
                "https://thumbs.dreamstime.com/b/beautiful-girl-doing-yoga-lotus-posture-breath-rest-young-ballet-dancer-training-dancing-gym-78305875.jpg",
                "https://thumbs.dreamstime.com/b/fetus-yoga-posture-attractive-indian-young-man-black-sport-leggings-practicing-fitness-pilates-red-mat-park-doing-61332746.jpg",
                // Add more image URLs as needed
            ],
        };
    }

    handleImageClick = (imageUrl) => {
        // Add your custom click event logic here
        console.log("Image clicked:", imageUrl);
    };

    render() {
        const { imageUrls } = this.state;

        return (
            <>
            <h1 style={{ textAlign: "center", margin: "3px 3px 3px 3px" }}>Exercises</h1>
            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
                gap: '16px',
                padding: '16px',
                backgroundColor: 'rgb(2221, 2221, 99)', 
            }}>
                {imageUrls.map((imageUrl, index) => (
                    <img
                        key={index}
                        src={imageUrl}
                        alt={`Image ${index + 1}`}
                        className="image"
                        style={{
                            width: '100%',
                            height: '100%',
                            objectFit: 'cover',
                            borderRadius: '8px',
                            cursor: 'pointer',
                            transition: 'transform 0.2s ease-in-out',
                        }}
                        onClick={() => this.handleImageClick(imageUrl)}
                    />
                ))}
            </div>
            </>
        );
    }
}

export default ImageGrid;
