// ProgressTracker.js
import React, { useState, useEffect } from 'react';
import './ProgressTracker.css';

const ProgressTracker = () => {
  const [completedSessions, setCompletedSessions] = useState(0);
  const [totalMeditationTime, setTotalMeditationTime] = useState(0);
  const [userFeedback, setUserFeedback] = useState('');
  const [meditationInProgress, setMeditationInProgress] = useState(false);
  const [startTime, setStartTime] = useState(null);

  // Handle the start of a meditation session
  const startMeditation = () => {
    setMeditationInProgress(true);
    setStartTime(Date.now());
  };

  // Handle the end of a meditation session
  const endMeditation = () => {
    setMeditationInProgress(false);
    const endTime = Date.now();
    const sessionTime = (endTime - startTime) / 1000; // Convert to seconds
    setTotalMeditationTime(totalMeditationTime + sessionTime);
    setCompletedSessions(completedSessions + 1);
  };

  // Handle user feedback
  const handleUserFeedback = (event) => {
    setUserFeedback(event.target.value);
  };

  useEffect(() => {
    // Save progress data to a server or local storage
    // In a real application, you'd likely save this data to a database or external storage.
  }, [completedSessions, totalMeditationTime, userFeedback]);

  return (
    <div className="progress-tracker">
      <h2>Progress Tracker</h2>
      <div className="tracker-data">
        <p>Sessions Completed: {completedSessions}</p>
        <p>Total Meditation Time (in seconds): {totalMeditationTime}</p>
      </div>
      <div className="meditation-controls">
        {!meditationInProgress ? (
          <button onClick={startMeditation}>Start Meditation</button>
        ) : (
          <button onClick={endMeditation}>End Meditation</button>
        )}
      </div>
      {/* <div className="feedback">
        <h3>Session Feedback:</h3>
        <textarea
          rows="4"
          cols="50"
          value={userFeedback}
          onChange={handleUserFeedback}
          placeholder="Share your feedback..."
        ></textarea>
      </div> */}
    </div>
  );
};

export default ProgressTracker;
