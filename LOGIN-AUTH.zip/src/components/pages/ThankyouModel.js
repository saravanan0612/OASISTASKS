import React from 'react';

const ThankYouModal = ({ onClose }) => {
  return (
    <div className="modal-overlay">
      <div className="modal">
        <p>Thank you for your feedback!</p>
        <button onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default ThankYouModal;
