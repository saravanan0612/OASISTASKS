import React, { useState, useRef } from 'react';
import './Playlist.css'; // Import the new CSS file
import song1 from '../../assets/audio/1.mp3';
import song2 from '../../assets/audio/2.mp3';
import song3 from '../../assets/audio/3.mp3';
import song4 from '../../assets/audio/4.mp3'
import song5 from '../../assets/audio/5.mp3'
import song6 from '../../assets/audio/6.mp3'
import { Link } from 'react-router-dom/cjs/react-router-dom.min';
function NewPlaylist() {
  const [playlist, setPlaylist] = useState([
    { id: 1, name: 'Calm and Peaceful', src: song1 },
    { id: 2, name: 'Lilac', src: song2 },
    { id: 3, name: 'Melody of Nature', src: song3 },
    { id: 4, name: 'child dreams', src: song4 },
    { id: 5, name: 'peonies', src: song5 },
    { id: 6, name: 'sunset', src: song6 },
    // { id: 7, name: 'relaxo', src: song2 },
    // { id: 8, name: 'mindfull', src: song3 },
  ]);
  const [currentTrack, setCurrentTrack] = useState(0);
  const [newSong, setNewSong] = useState(''); // State for the new song input
  const audioRef = useRef(null);

  const playTrack = (trackIndex) => {
    setCurrentTrack(trackIndex);
    audioRef.current.load();
    audioRef.current.play();
  };

  const nextTrack = () => {
    if (currentTrack < playlist.length - 1) {
      setCurrentTrack(currentTrack + 1);
      audioRef.current.load();
      audioRef.current.play();
    }
  };

  const previousTrack = () => {
    if (currentTrack > 0) {
      setCurrentTrack(currentTrack - 1);
      audioRef.current.load();
      audioRef.current.play();
    }
  };

  // Function to add a new song to the playlist
  const addSong = () => {
    if (newSong.trim() !== '') { // Check if the input is not empty
      // Check for duplicates based on song name
      const isDuplicate = playlist.some((song) => song.name === newSong);
      if (!isDuplicate) {
        setPlaylist([...playlist, { id: playlist.length + 1, name: newSong, src: newSong }]);
        setNewSong(''); // Clear the input field
      }
    }
  };

  return (
    <div className="new-beautiful-playlist">
      <h1 className="new-h1">My Playlist</h1>
      <audio ref={audioRef} controls src={playlist[currentTrack].src} className="new-audio" />
      <ul className="new-ul">
        {playlist.map((song, index) => (
          <li key={song.id} className="new-li">
            {song.name}
            <button onClick={() => playTrack(index)} className="new-button">Play</button>
          </li>
        ))}
      </ul>
      <div className="new-controls">
        <button onClick={previousTrack} className="new-button">Previous</button>
       
        <Link to = "/home">
        <button onClick={nextTrack} className="new-button">back</button>
        </Link>
       
        <button onClick={nextTrack} className="new-button">Next</button>

      </div>
      {/* <div>
        <input
          type="text"
          placeholder="Enter the song name or URL"
          value={newSong}
          onChange={(e) => setNewSong(e.target.value)}
          className="new-input"
        />
        <button onClick={addSong} className="new-button" type="button">Add Song</button>
      </div> */}
    </div>
  );
}

export default NewPlaylist;