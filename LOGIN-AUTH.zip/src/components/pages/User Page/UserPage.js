import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
const UsersPage = () => {
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);
  const fetchData = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8080/courses', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json', // You can include other headers if needed
        },
      });

      if (response.ok) {
        const data = await response.json();
        setCourses(data);
      } else {
        console.error('Failed to fetch course data. Please try again.');
      }
    } catch (error) {
      console.error('An error occurred:', error);
    }
  };

  return (
    <div className="users-page">
      <h1 className="course-list-title">Course List</h1>
      <Link to="/trainerslist">
        <button className="courses-button">Trainers</button>
      </Link>
      <Link to="/home">
        <button className="courses-button">back</button>
      </Link>
      <table className="course-table">
        <thead>
          <tr>
            <th className="course-name">Course Name</th>
            <th className="duration-hours">Duration (hours)</th>
            <th className="course-price">Price</th>
          </tr>
        </thead>
        <tbody>
          {courses.map((course) => (
            <tr key={course.id}>
              <td className="course-name">{course.coursename}</td>
              <td className="duration-hours">{course.duration}</td>
              <td className="course-price">{course.price}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UsersPage;
