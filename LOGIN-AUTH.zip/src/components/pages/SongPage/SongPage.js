import React, { useState, useEffect } from 'react';
import './SongPage.css';

const SongPage = () => {
  const [songs, setSongs] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [songName, setSongName] = useState('');
  const [artistName, setArtistName] = useState('');
  const [songGenre, setSongGenre] = useState('');
  const [songDuration, setSongDuration] = useState('');
  const [editSongId, setEditSongId] = useState(null);

  const fetchData = async () => {
    try {
      // Fetch your songs data here using an API endpoint or other data source
      // Update setSongs with your songs data
    } catch (error) {
      console.error('An error occurred:', error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const formData = {
      songName,
      artistName,
      songGenre,
      songDuration: parseInt(songDuration), // Convert songDuration to an integer
    };

    try {
      let response;

      if (editSongId) {
        // Handle the PUT request to update an existing song
      } else {
        // Handle the POST request to create a new song
      }

      if (response.ok) {
        const updatedSong = await response.json();
        if (editSongId) {
          // Update the songs array with the updated song
        } else {
          // Add the new song to the songs array
        }

        // Clear form inputs and state
        setSongName('');
        setArtistName('');
        setSongGenre('');
        setSongDuration('');
        setShowForm(false);
        setEditSongId(null);
      } else {
        console.error('Failed to add/update song. Please try again.');
      }
    } catch (error) {
      console.error('An error occurred:', error);
    }
  };

  const handleFormCancel = () => {
    // Clear form inputs and state
    setSongName('');
    setArtistName('');
    setSongGenre('');
    setSongDuration('');
    setShowForm(false);
    setEditSongId(null);
  };

  const handleEditSong = (id) => {
    const selectedSong = songs.find((song) => song.id === id);
    if (selectedSong) {
      // Set form fields with the selected song's data
      setSongName(selectedSong.songName);
      setArtistName(selectedSong.artistName);
      setSongGenre(selectedSong.songGenre);
      setSongDuration(selectedSong.songDuration.toString()); // Convert songDuration to string
      setEditSongId(id);
      setShowForm(true);
    }
  };

  const handleDeleteSong = async (id) => {
    // Handle the DELETE request to remove a song by its ID
  };

  return (
    <div className="trainer-page-container">
      <div className="buttons-to-add">
        <button className="add-trainer-button" onClick={() => setShowForm(true)}>
          Add Song
        </button>
      </div>
      {showForm && (
        <div className="add-trainer-form">
          <form onSubmit={handleFormSubmit}>
            <ul className="form-list">
              <li className="form-item">
                <label className="form-field-input-data" htmlFor="songName">
                  Song Name:
                </label>
                <input
                  id="songName"
                  type="text"
                  value={songName}
                  onChange={(e) => setSongName(e.target.value)}
                />
              </li>
              <li className="form-item">
                <label className="form-field-input-data" htmlFor="artistName">
                  Artist Name:
                </label>
                <input
                  id="artistName"
                  type="text"
                  value={artistName}
                  onChange={(e) => setArtistName(e.target.value)}
                />
              </li>
              <li className="form-item">
                <label className="form-field-input-data" htmlFor="songGenre">
                  Song Genre:
                </label>
                <input
                  id="songGenre"
                  type="text"
                  value={songGenre}
                  onChange={(e) => setSongGenre(e.target.value)}
                />
              </li>
              <li className="form-item">
                <label className="form-field-input-data" htmlFor="songDuration">
                  Song Duration (in seconds):
                </label>
                <input
                  id="songDuration"
                  type="text"
                  value={songDuration}
                  onChange={(e) => setSongDuration(e.target.value)}
                />
              </li>
            </ul>
            <div className="form-buttons">
              <button className="submit-trainer-button" type="submit">
                {editSongId ? 'Update' : 'Create'}
              </button>
              <button
                className="cancel-trainer-button"
                type="button"
                onClick={handleFormCancel}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}
      <div className="table-container">
        <table className="trainer-table">
          <thead>
            <tr>
              <th>Song Name</th>
              <th>Artist Name</th>
              <th>Song Genre</th>
              <th>Song Duration (s)</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {songs.map((song) => (
              <tr key={song.id}>
                <td>{song.songName}</td>
                <td>{song.artistName}</td>
                <td>{song.songGenre}</td>
                <td>{song.songDuration}</td>
                <td>
                  <button
                    className="edit-trainer-button"
                    onClick={() => handleEditSong(song.id)}
                  >
                    Edit
                  </button>
                  <button
                    className="delete-trainer-button"
                    onClick={() => handleDeleteSong(song.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SongPage;
