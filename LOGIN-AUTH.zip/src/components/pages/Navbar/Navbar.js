import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './NavbarStyles.css';

const Navbar = () => {
  const [activeLink, setActiveLink] = useState('home');

  const handleLinkClick = (link) => {
    setActiveLink(link);
  };

  const handleLogout = () => {

    window.location.href = '/'; 
  };

  return (
    <nav className="navbar">
      <ul className="navbar-list">
        <li className={`navbar-item ${activeLink === 'home' ? 'active' : ''}`}>
          <Link to="/home" onClick={() => handleLinkClick('home')} style={{ color: 'white' }}>Home</Link>
        </li>
        <li className={`navbar-item ${activeLink === 'about' ? 'active' : ''}`}>
          <Link to="/about" onClick={() => handleLinkClick('about')} style={{ color: 'white' }}>About</Link>
        </li>
        <li className={`navbar-item ${activeLink === 'contact' ? 'active' : ''}`}>
          <Link to="/FAQ" onClick={() => handleLinkClick('')} style={{ color: 'white' }}>FAQ</Link>
        </li>
        <li className={`navbar-item ${activeLink === 'contact' ? 'active' : ''}`}>
          <Link to="/UsersPage" onClick={() => handleLinkClick('')} style={{ color: 'white' }}>Courses</Link>
        </li>
        <li className={`navbar-item ${activeLink === 'contact' ? 'active' : ''}`}>
          <Link to="/playlist" onClick={() => handleLinkClick('')} style={{ color: 'white' }}>Playlist</Link>
        </li>
        <li className={`navbar-item ${activeLink === 'contact' ? 'active' : ''}`}>
          <Link to="/how" onClick={() => handleLinkClick('')} style={{ color: 'white' }}>Exercises</Link>
        </li>
      </ul>
      <div className="logout-button">
        <button onClick={handleLogout}>Logout</button>
      </div>
    </nav>
  );
};

export default Navbar;
