import React, { useEffect, useState } from 'react';
import { SidebarData } from '../SideBar/SidebarData';
import './Dashboard.css'; // Import your CSS for additional styling
import Widget from './Widget';

function Dashboard() {
  const [dashboardData, setDashboardData] = useState({
    totalUsers: 0,
    totalTrainers: 0,
    totalCourses: 0,
  });

  useEffect(() => {
    // Simulating fetching data from an API
    fetchData().then((data) => {
      setDashboardData(data);
    });
  }, []);

  // Simulated API call (replace with actual API call)
  const fetchData = async () => {
    return {
      totalUsers: 1000,
      totalTrainers: 50,
      totalCourses: 20,
    };
  };

  return (
    <div className="dashboard-container">
      {/* Sidebar */}
      <nav className="sidebar">
        <ul className="nav-menu">
          {SidebarData.map((item, index) => (
            <li key={index} className="nav-item">
              <a href={item.path} className="nav-link">
                {item.icon}
                <span className="nav-text">{item.title}</span>
              </a>
            </li>
          ))}
        </ul>
      </nav>

      {/* Main Content */}
      {/* <div className="content-container">
        <header className="dashboard-header">
          <h1>Welcome to the Meditation App</h1>
        </header>

        <div className="dashboard-section">
          <div className="row">
            <div className="col-md-4">
              <div className="dashboard-box">
                <h2>Users</h2>
                <p className="box-value">{dashboardData.totalUsers}</p>
              </div>
            </div>

            <div className="col-md-4">
              <div className="dashboard-box">
                <h2>Trainers</h2>
                <p className="box-value">{dashboardData.totalTrainers}</p>
              </div>
            </div>

            <div className="col-md-4">
              <div className="dashboard-box">
                <h2>Courses</h2>
                <p className="box-value">{dashboardData.totalCourses}</p>
              </div>
            </div>
          </div> */}

          {/* Add more boxes or customize as needed */}
          <div className="wrapper wrapper-content animated fadeInRight">
                            <div className="row">
                                <div className="col-lg-3">
                                    <div className="widget style1 navy-bg">
                                        <Widget name="Total Relaxation Time" count="40" icon_name="fa fa-hourglass-half fa-5x" />
                                    </div>
                                </div>
                                <div className="col-lg-3">
                                    <div className="widget style1 lazur-bg">
                                        <Widget name="Total Users" count="20" icon_name="fa fa-user-circle" />
                                    </div>
                                </div>
                                <div className="col-lg-3">
                                    <div className="widget style1 yellow-bg">
                                        <Widget name="Guide for Relaxation" count="" icon_name="fa fa-leanpub fa-5x" />
                                    </div>
                                </div>
                                <div className="col-lg-3">
                                    <div className="widget style1 red-bg">
                                        <Widget name="Team member" count="5" icon_name="fa fa-users fa-5x" />
                                    </div>
                                </div>
                                <div className="col-lg-3">
                                    <div className="widget style1 blue-bg">
                                        <Widget name="To-Dos" count="5" icon_name="fa fa-address-card" />
                                    </div>
                                </div>
                                <div className="col-lg-3">
                                    <div className="widget style1 purple-bg">
                                        <Widget name="Total Diary Entries" count="27" icon_name="fa fa-book fa-5x" />
                                    </div>
                                </div>
                                <div className="col-lg-3">
                                    <div className="widget style1 green-bg">
                                        <Widget name="Heart Rate" count="27" icon_name="fa fa-heartbeat fa-5x" />
                                    </div>
                                </div>
                                <div className="col-lg-3">
                                    <div className="widget style1 ash-bg">
                                        <Widget name="Notification" count="27" icon_name="fa fa-envelope" />
                                    </div>
                                </div>
                            </div>
                        </div>
        </div>
      // </div>
    // </div>
  );
}

export default Dashboard;
