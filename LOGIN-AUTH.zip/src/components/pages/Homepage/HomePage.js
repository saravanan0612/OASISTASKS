import React from 'react';
import { useHistory } from 'react-router-dom';
import Navbar from '../Navbar/Navbar';
import './HomePage.css';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';

const Home = () => {
  const history = useHistory();

  const handleGetStartedClick = () => {
    history.push('/meditation'); // Navigate to the "Meditate" route.
  };

  return (
    <div className="home-container">
      <Navbar />
      <header className="header">
        <h1>Welcome to the Meditation App</h1>
        <p>Discover Inner Peace and Relaxation</p>
        
        <button className="get-started-button" onClick={handleGetStartedClick}>
          Get Started
        </button>
      
      </header>

      <div className="content">
        <div className="content-item">
          <h2>Guided Meditation</h2>
          <p>Explore a variety of meditation sessions guided by experts.</p>
        </div>

        <div className="content-item">
          <h2>Mindfulness</h2>
          <p>Practice mindfulness to reduce stress and enhance well-being.</p>
        </div>

        <div className="content-item">
          <h2>Relaxation Techniques</h2>
          <p>Learn relaxation techniques for a calm and focused mind.</p>
        </div>
      </div>

               


      <h2 class="css-a8uy5g" data-testid="section-with-tabs-module-title"> Get some Relaxfull space</h2>
      <a class="css-ager1h" href="https://checkout.headspace.com/checkout?voucherCode=BF2023A&origin=tabbed-feature" target="_self" rel data-testid="section-with-tabs-button-link">
      <Link to="/meditation" className="get-started-button">
          Get Started
        </Link>
      </a>
      

      {/* <h2 class="css-4u6ees" data-testid="module-title">Latest articles</h2> */}
      {/* <div class="background-container css-15vu3re" data-testid="background-content-container">
        <h2 class="css-z5lz7m" data-testid="hero-module-title">All articles</h2>
      <p>
        "Hundreds of articles for any mind, any mood, any goal. Browse all of our articles on meditation, mindfulness, sleep, and more."
      </p>
      </div> */}


  
  {/* <div class="et_pb_main_blurb_image">
 <div class="et_pb_blurb_container">
    <span class="et_pb_image_wrap et_pb_only_image_mode_wrap">
  <img decoding="async" src="https://sos-stage.sos-dev.org/wp-content/uploads/2020/05/200-200-meditator-icon.svg" alt class="et-waypoint et_pb_animation_off et_pb_animation_off_tablet et_pb_animation_off_phone et-animated"></img>
  </span>
  <h4 class="et_pb_module_header">
    <span>One hour program</span>
  </h4>
  </div> */}

<div id="sos-event-list-section" class="et_pb_section et_pb_section_1 et_section_regular">
<div class="et_pb_text_inner">
  <h2>Online Meditation Class</h2>
  <p>Rate your experience</p>
  <Link to="/rating" className="get-started-button">
           Rate
        </Link>
</div>
  </div>

  <div class="et_pb_main_blurb_image">
 <div class="et_pb_blurb_container">
    <span class="et_pb_image_wrap et_pb_only_image_mode_wrap">
  <img decoding="async" src="https://sos-stage.sos-dev.org/wp-content/uploads/2020/05/200-200-one-hour-clock.svg" alt class="et-waypoint et_pb_animation_off et_pb_animation_off_tablet et_pb_animation_off_phone et-animated"></img>
  </span>
  <h4 class="et_pb_module_header">
    <span>Time Limit</span>
  </h4>
  </div>
  </div>  
  
  <div class="et_pb_main_blurb_image">
 <div class="et_pb_blurb_container">
    <span class="et_pb_image_wrap et_pb_only_image_mode_wrap">
      <img decoding="async" src="https://sos-stage.sos-dev.org/wp-content/uploads/2020/05/200-200-open-hands.svg" alt class="et-waypoint et_pb_animation_off et_pb_animation_off_tablet et_pb_animation_off_phone et-animated"></img>
  </span>
  <h4 class="et_pb_module_header">
    <span> Interactive </span>
  </h4>
  </div>
  </div>
    
  <div class="et_pb_main_blurb_image">
 <div class="et_pb_blurb_container">
    <span class="et_pb_image_wrap et_pb_only_image_mode_wrap">
  <img decoding="async" src="https://sos-stage.sos-dev.org/wp-content/uploads/2020/05/200-200-meditator-icon.svg" alt class="et-waypoint et_pb_animation_off et_pb_animation_off_tablet et_pb_animation_off_phone et-animated"></img>
  </span>
  <h4 class="et_pb_module_header">
    <span>Meditation sessions</span>
  </h4>
  </div>
  </div>  

  <div className="about-meditation">
        <h2>About Meditation</h2>
        <p>Meditation is a practice that involves focusing your mind on a particular object, thought, or activity to train attention and awareness. It is often used to reduce stress, promote relaxation, and enhance personal and spiritual growth. Meditation can have a positive impact on your physical and mental well-being, helping you find inner peace and clarity.</p>
      </div>
      
      
      <div className="meditation-cost">
        <h2>Cost of Meditation Courses</h2>
        <p>Our meditation courses are designed to be affordable and accessible to all. Prices vary based on the type of course and duration. Contact us for detailed pricing information and special offers.</p>
      </div> 



<div class="et_pb_section et_pb_section_10 et_section_regular">
  <div class="et_pb_column et_pb_column_1_2 et_pb_column_27  et_pb_css_mix_blend_mode_passthrough">
    <div class="et_pb_module et_pb_text et_pb_text_17  et_pb_text_align_left et_pb_bg_layout_dark">
     <div style={{display:"flex"}}>
      <div class="et_pb_text_inner">
        <h3>Contact Us</h3>
      </div> 
      <div className='con_container'> 
        <p>Email: <a href="mailto:webinar@sos.org">calmly@gmail.com</a></p>
        <p>Phone: +1 (555) 123-4567</p>
        <p>Address: 123 Main Street, City, Country</p>
        
      </div>
      </div>
    </div>
  </div>
</div>



 </div>

  );
};

export default Home;