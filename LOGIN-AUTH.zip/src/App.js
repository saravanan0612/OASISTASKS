import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './components/redux/Store'; 
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import LandingPage from './components/pages/LandingPage/LandingPage';
import LoginPage from './components/pages/LoginPage/LoginPage';
import RegisterPage from './components/pages/Register/RegisterPage';
import ForgetPasswordPage from './components/pages/Forgot Password/ForgetPasswordPage';
import HomePage from './components/pages/Homepage/HomePage';
import AdminLogin from './components/pages/AdminLogin/AdminLogin';
import DashBoardPage from './components/pages/Dashboard/Dashboard';
import CoursePage from './components/pages/CoursePage/CoursePage';
import FAQ from './components/pages/Faq/FAQAPP';
import TermsAndConditions from './components/pages/Terms and Conditions/terms';
import PrivacyPolicy from './components/pages/Privacy Policy/privacypolicyApp';
import Meditation from './components/pages/Meditation/meditation';
import UsersPage from './components/pages/User Page/UserPage';
import TrainerPage from './components/pages/Trainer/trainer';
import About from './components/pages/About/About';
import ProgressTracker from './components/pages/Progress Tracker/ProgressTracker';
import MeditationSession from './components/pages/MeditationSession/MeditationSession';
import SongPage from './components/pages/SongPage/SongPage';
import TrainersPage from './components/pages/trainersPage';
import NewPlaylist from './components/pages/Playlist';
import how from './components/pages/how';
import StarRating from './components/pages/rating';
import ThankYouModal from './components/pages/ThankyouModel';


function App() {
  const role = localStorage.getItem('role');
  return (
    <Provider store={store}>
      <Router>
        <div>
          {/* <HeaderComponent /> */}
          {/* <Navbar/> */}
          <Switch>
            <Route exact path="/" component={LandingPage} />
            <Route path="/login" component={LoginPage} />
            <Route path="/register" component={RegisterPage} />
            <Route path="/forgot-password" component={ForgetPasswordPage} />
            <Route path="/home" component={HomePage} />
            <Route path="/FAQ" component={FAQ} />
            <Route path="/tac" component={TermsAndConditions} />
            <Route path="/privacy-policy" component={PrivacyPolicy} />
            <Route path="/meditation" component={Meditation} />
            <Route path="/UsersPage"component={UsersPage}/>
            <Route path="/song"component={UsersPage}/>
            <Route path="/about"component={About}/>
            <Route path="/progress"component={ProgressTracker}/>
            <Route path="/ms"component={MeditationSession}/>
            <Route path="/song"component={SongPage}/>
            <Route path="/trainerslist"component={TrainersPage}/>
            <Route path="/playlist"component={NewPlaylist}/>
            <Route path="/trainer"component={TrainerPage}/>
            <Route path="/CoursePage" component={CoursePage} />
            <Route path="/dashboard" component={DashBoardPage} />
            <Route path="/AdminLogin" component={AdminLogin} />
            <Route path="/how" component={how} />
            <Route path="/rating" component={StarRating} />
            <Route path="/thankyou" component={ThankYouModal} />
            </Switch>
          <FooterComponent />
        </div>
      </Router>
    </Provider>
  );
}

export default App;
