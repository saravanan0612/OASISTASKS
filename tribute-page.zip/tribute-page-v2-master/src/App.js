import React, { Component } from 'react';
import './styles/App.css';
import { Main } from './components/Main';

class App extends Component {
  render() {
    return (
      <div className="App" id="#page">
          <Main/>          
      </div>
    );
  }
}

export default App;
